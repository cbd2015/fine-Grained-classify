# finetune_classification
使用 TensorFlow 进行 finetuning 的通用分类模型

## 使用方式
请参考：[TensorFlow 使用预训练模型 ResNet-50](https://www.jianshu.com/p/0237ebbee5d5)
